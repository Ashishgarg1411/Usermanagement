const  companydb = require('../../models/admin/companydb')

exports.companyshow= async (req, res) => {
    const record = await companydb.find()
    res.render('admin/company.ejs', { record })
}

exports.companyinsertshow=  (req, res) => {
    res.render('admin/companyinsert.ejs')
}

exports.companyadd= async (req, res) => {
    const { img, cname } = req.body
    if (req.file) {
        const filename = req.file.filename
        const record = new companydb({ image: filename, cname: cname })
        await record.save()
    } else {
        const record = new companydb({ cname: cname })
    }
    res.redirect('/admin/company')
}

exports.companyupdateshow= async (req, res) => {
    const id = req.params.id
    const record = await companydb.findById(id)
    res.render('admin/companyupdate.ejs', { record })
}

exports.companyupdate= async (req, res) => {
    const id = req.params.id
    const { img, cname } = req.body
    if (req.file) {
        const filename = req.file.filename
        await companydb.findByIdAndUpdate(id, { image: filename, cname: cname })
    } else {
        await companydb.findByIdAndUpdate(id, { cname: cname })
    }
    res.redirect('/admin/company')
}

exports.companydelete= async (req,res)=>{

    const id= req.params.id
    const record = await companydb.findByIdAndDelete(id)
    res.redirect('/admin/company')

}
