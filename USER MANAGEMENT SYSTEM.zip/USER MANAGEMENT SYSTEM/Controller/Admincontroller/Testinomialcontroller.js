const testidb = require('../../models/admin/testidb')

exports.testishow= async (req, res) => {
    const record = await testidb.find().sort({ postedDate: -1 })
    const totalrecord = await testidb.find().count()
    const totalpublish = await testidb.find().count({ status: 'publish' })
    const totalunpublish = await testidb.find().count({ status: 'unpublish' })
    res.render('admin/testi.ejs', { record, totalrecord, totalpublish, totalunpublish })
}

exports.testidelete= async (req, res) => {
    const id = req.params.id
    await testidb.findByIdAndDelete(id)
    res.redirect('/admin/testi')
}

exports.testiupdate=  async (req, res) => {
    const id = req.params.id
    const record = await testidb.findById(id)

    let newStatus = null

    if (record.status == 'unpublish') {
        newStatus = 'publish'
    }
    else {
        newStatus = 'unpublish'
    }

    await testidb.findByIdAndUpdate(id, { status: newStatus })

    res.redirect('/admin/testi')
}

