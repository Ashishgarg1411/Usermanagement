const  regdb = require('../../models/admin/regdb')

exports.usershow=async (req, res) => {
    const record = await regdb.find().sort({ registerDate: -1 })
    const tuseridstastus = await regdb.count()
    const tactive = await regdb.count({ status: 'active' })
    const tsuspended = await regdb.count({ status: 'suspended' })

    const tidrole = await regdb.count()
    const tpvt = await regdb.count({ role: 'pvt' })
    const tpublic = await regdb.count({ role: 'public' })
    res.render('admin/users.ejs', { record, tuseridstastus, tactive, tsuspended, tidrole, tpvt, tpublic })

}

exports.userupdateshow= async (req, res) => {
    const id = req.params.id
    const record = await regdb.findById(id)

    let newstatus = null
    if (record.status == 'suspended') {
        newstatus = 'active'
    } else {
        newstatus = 'suspended'
    }
    await regdb.findByIdAndUpdate(id, { status: newstatus })
    res.redirect('/admin/users')
}

exports.userstatus= async (req, res) => {
    const id = req.params.id
    const record = await regdb.findById(id)

    let newrole = null
    if (record.role == 'public') {
        newrole = 'pvt'
    } else {
        newrole = 'public'
    }
    await regdb.findByIdAndUpdate(id, { role: newrole })
    res.redirect('/admin/users')
}

exports.userdelete= async (req, res) => {
    const id = req.params.id
    await regdb.findByIdAndDelete(id)
    res.redirect('/admin/users')
}



