const bannerdb = require('../../models/admin/bannerdb')

exports.bannershow= async (req, res) => {
    const record = await bannerdb.find()
    res.render('admin/banner.ejs', { record })
}

exports.banneradd= (req, res) => {
    res.render('admin/banneradd.ejs')

}
exports.banneraddinsert= async (req, res) => {
    const { bt, bd, bld, } = req.body
    if (req.file) {
        const filename = req.file.filename
        const record = new bannerdb({ title: bt, desc: bd, ldesc: bld, img: filename })
        await record.save()
        console.log(record)
    } else {
        const record = new bannerdb({ title: bt, desc: bd, ldesc: bld })
    }

    res.redirect('/admin/banner')
}

exports.bannerupdateshow= async (req, res) => {
    const id = req.params.abc
    const record = await bannerdb.findById(id)
    res.render('admin/bannerupdate.ejs', { record })
}

exports.bannerupdateinsert= async (req, res) => {
    const { bt, bd, bld } = req.body
    const id = req.params.def
    if (req.file) {
        const filename = req.file.filename
        await bannerdb.findByIdAndUpdate(id, { title: bt, desc: bd, ldesc: bld, img: filename })
    } else {
        await bannerdb.findByIdAndUpdate(id, { title: bt, desc: bd, ldesc: bld })
    }
    res.redirect('/admin/banner')

}

exports.bannerdelete= async (req, res) => {
    const id = req.params.abc
    await bannerdb.findByIdAndDelete(id)
    res.redirect('/admin/banner')
}