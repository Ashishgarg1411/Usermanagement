const  regdb = require('../../models/admin/regdb')
const  addressdb = require('../../models/admin/addressdb')
const  companydb = require('../../models/admin/companydb')
let sess= null;


exports.regshow= async (req, res) => {
    const addressview = await addressdb.findOne()
    const companyview = await companydb.findOne()
    if (sess !== null) {
      res.render('reg.ejs', { addressview, companyview, username: sess.username })
    } else {
      res.render('reg.ejs', { addressview, companyview, username: 'hello' })
    }
  }

  exports.reginsert= async (req, res) => {
    const { us, pass } = req.body
    const usercheck = await regdb.findOne({ username: us })
    if (usercheck == null) {
      const record = new regdb({ username: us, password: pass, registerDate: new Date() })
      await record.save()
      res.redirect('/login')
    } else {
      res.send("Username Already taken")
    }
  
  }
