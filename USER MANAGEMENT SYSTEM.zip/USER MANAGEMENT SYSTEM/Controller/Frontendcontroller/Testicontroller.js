const  testidb = require('../../models/admin/testidb')
const  addressdb = require('../../models/admin/addressdb')
const  companydb = require('../../models/admin/companydb')
let sess= null;

function handlerole(req, res, next) {
  if (sess.userrole == 'pvt') {
    next()
  } else {
    res.send("You don't have right to see this page.")
  }
}

function handlelogin(req, res, next) {
  if (req.session.isAuth) {
    next()
  } else {
    res.redirect('/login')
  }
}


exports.testishow=  async (req, res) => {
    const addressview = await addressdb.findOne()
    const companyview = await companydb.findOne()
    const record = await testidb.find()
    if (sess !== null) {
      res.render('testiform.ejs', { record, addressview, companyview, username: sess.username })
    } else {
      res.render('testiform.ejs', { record, addressview, companyview, username: 'hello' })
    }
  
  }

  exports.testiinsert= async (req, res) => {
    const { quotes, cname } = req.body
    if (req.file) {
      const filename = req.file.filename
      const record = new testidb({ image: filename, quotes: quotes, cname: cname, postedDate: new Date(), status: 'unpublish' })
      await record.save()
    } else {
      const record = new testidb({ quotes: quotes, cname: cname, postedDate: new Date(), status: 'unpublish' })
    }
  
    res.redirect('/')
    //console.log(record)
  }