const  servicedb = require('../../models/admin/servicedb')
const  addressdb = require('../../models/admin/addressdb')
const  companydb = require('../../models/admin/companydb')
let sess= null;

exports.servicesshow=  async (req, res) => {
    const id = req.params.xyz
    const addressview = await addressdb.findOne()
    const companyview = await companydb.findOne()
    const record = await servicedb.findById(id)
    if(sess!==null){
      res.render('moredetailcontain.ejs', { record, addressview, companyview, username: sess.username })
    }else{
      res.render('moredetailcontain.ejs', { record, addressview, companyview, username: 'hello' })
    }
  }

