const regdb= require('../../models/admin/regdb')
const  addressdb = require('../../models/admin/addressdb')
const  companydb = require('../../models/admin/companydb')
const bannerdb= require('../../models/admin/bannerdb')
const servicedb= require('../../models/admin/servicedb')
const testidb= require('../../models/admin/testidb')
let sess= null;


exports.homepage= async (req, res) => {
  const record = await bannerdb.findOne()
  const servires = await servicedb.find({ status: 'publish' })
  const testi = await testidb.find({ status: 'publish' })
  const addressview = await addressdb.findOne()
  const companyview = await companydb.findOne()
  if (sess !== null) {
    res.render('index.ejs', { record, servires, testi, addressview, companyview, username: sess.username })
  } else {
    res.redirect('/login', { record, servires, testi, addressview, companyview, username: 'hello' })

  }
}

exports.loginshow=async (req, res) => {
    const addressview = await addressdb.findOne()
    const companyview = await companydb.findOne()
    if (sess !== null) {
      res.render('login.ejs', {message:'', addressview, companyview, username: sess.username })
    } else {
      res.render('login.ejs', {message:'', addressview, companyview, username: 'hello' })
    }
  }

  exports.logininsert= async (req, res) => {
    const { us, pass } = req.body
    const record = await regdb.findOne({ username: us })
    if (record !== null) {
      if (record.password == pass) {
        if (record.status == 'active') {
          req.session.isAuth = true
          sess = req.session
          sess.username = us
          sess.userrole = record.role
          res.redirect('/')
        } else {
          res.send("Your account is suspended. Please cordinate with your admin.")
        }
  
      } else {
        const addressview = await addressdb.findOne()
        const companyview = await companydb.findOne()
        if (sess !== null) {
          res.render('login.ejs', {message:'Wrong Credentails', addressview, companyview, username: sess.username })
        } else {
          res.render('login.ejs', { message:'Wrong Credentails',addressview, companyview, username: 'hello' })
        }
      }
    } else {
      const addressview = await addressdb.findOne()
      const companyview = await companydb.findOne()
      if (sess !== null) {
        res.render('login.ejs', {message:'Wrong Credentails', addressview, companyview, username: sess.username })
      } else {
        res.render('login.ejs', { message:'Wrong Credentails',addressview, companyview, username: 'hello' })
      }
    }
  }

  exports.logout=(req, res) => {
    req.session.destroy()
    sess = null
    res.redirect('/login')
  }