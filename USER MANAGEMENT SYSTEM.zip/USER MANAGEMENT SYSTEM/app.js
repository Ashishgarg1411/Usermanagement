const express = require('express') //module
const app = express() //modole
app.use(express.urlencoded({extended:false}))
const adminrouter = require('./routers/admin/admin')
const frontrouter = require('./routers/frontend/frontend')
const session = require('express-session')


const mongoose = require('mongoose')
mongoose.connect('mongodb://127.0.0.1:27017/project2express',()=>{
    console.log('connected to DB project2express')
 })




app.use(session({
    secret:'vivek',
    resave:false,
    saveUninitialized:false
}))

app.use('/admin',adminrouter)
app.use(frontrouter)
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(5000, ()=>{
    console.log('server is ruuning on port 5000')
})