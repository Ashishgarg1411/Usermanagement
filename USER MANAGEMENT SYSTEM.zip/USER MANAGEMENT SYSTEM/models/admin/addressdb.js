const mongoose = require('mongoose')


const addressSchema=mongoose.Schema({
    address:String,
    mobile:String,
    telephone:String
})





module.exports = mongoose.model('address',addressSchema)