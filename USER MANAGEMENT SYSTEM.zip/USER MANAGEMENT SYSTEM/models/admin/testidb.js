const mongoose = require('mongoose')


const testiSchema = mongoose.Schema({
    image: String,
    quotes: String,
    cname: String,
    postedDate: Date,
    status: String
})





module.exports = mongoose.model('testi', testiSchema)